package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import engine.Game;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class BoardPanel extends JPanel implements ActionListener {

	private PermanentFrame pf;

	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;

	// panel1
	private JButton[][] blocks;

	// panel 2
	private JTextArea currentPlayerMarvel;
	private JTextArea TurnOrder;

	// panel 3
	private JLabel FirstPlayerName;
	private JLabel SecondPlayerName;
	private JButton Left;
	private JButton Right;
	private JButton Down;
	private JButton Up;
	private JButton EndTurn;
	private JButton Move;

	private JButton AttackUp;
	private JButton AttackDown;
	private JButton AttackLeft;
	private JButton AttackRight;

	// panel 4
	private JComboBox PickAbilityToCast;
	private JTextArea Dimensions;
	private JButton throwCast;
	private JButton LeaderAbility;
	private JLabel BoardDimensions;
	

	private Direction way = Direction.UP;
	private Direction wayAttack;

	public BoardPanel(PermanentFrame pf,Game g) {

		this.pf = pf;
		this.setLayout(null);
		this.setBackground(Color.CYAN);

		// panel 1 setup
		panel1 = new JPanel();
		panel1.setLayout(new GridLayout(5, 5));
		panel1.setBounds(600, 15, 770, 520);
		this.add(panel1);
		
		blocks = new JButton[5][5];

		// to add buttons that contain marvels
		for (int i = 0; i < blocks.length; i++) {
			for (int k = 0; k < blocks.length; k++) {

				blocks[i][k] = new JButton();
				blocks[i][k].addActionListener(this);
				panel1.add(blocks[i][k]);

			}
		}

		// panel2
		panel2 = new JPanel();
		panel2.setLayout(null);
		panel2.setBounds(50, 400, 450, 350);
		this.add(panel2);

		currentPlayerMarvel = new JTextArea();
		currentPlayerMarvel.setBounds(40, 200, 250, 100);
		currentPlayerMarvel.setFont(new Font("MV Boli",Font.PLAIN,14));
		currentPlayerMarvel.setEditable(false);
		
		TurnOrder = new JTextArea ();
		TurnOrder.setBounds(255, 20, 190, 180);
		TurnOrder.setFont(new Font("MV Boli",Font.PLAIN,14));
		TurnOrder.setBackground(Color.RED);
		TurnOrder.setEditable(false);
		
		
		String s ="";
		PriorityQueue temp = new PriorityQueue(6);
		
		
		while(!g.getTurnOrder().isEmpty()) 
		{
			s += ((Champion)g.getTurnOrder().peekMin()).getName()+"\n";
			temp.insert(g.getTurnOrder().remove());	
		}
		while(!temp.isEmpty())
		{
			g.getTurnOrder().insert(temp.remove());
		}
		
		TurnOrder.setText(s);
		panel2.add(TurnOrder);
		
		JScrollPane scrolldown = new JScrollPane(currentPlayerMarvel); 														
		scrolldown.setBounds(0, 0, 250, 350);
		scrolldown.setBackground(Color.blue);
		panel2.add(scrolldown);
		

		// panel 3 setup
		panel3 = new JPanel();
		panel3.setLayout(null);
		panel3.setBounds(600, 550, 750, 240);
		panel3.setBackground(Color.orange);
		this.add(panel3);
		

		FirstPlayerName = new JLabel("First Player : " + pf.getGame().getFirstPlayer().getName());
		FirstPlayerName.setBounds(50, 1, 150, 50);
		panel3.add(FirstPlayerName);

		SecondPlayerName = new JLabel("Second Player : " + pf.getGame().getSecondPlayer().getName());
		SecondPlayerName.setBounds(350, 1, 150, 50);
		panel3.add(SecondPlayerName);

		Up = new JButton("Up");
		Up.setBounds(80, 40, 80, 40);
		Up.addActionListener(this);
		panel3.add(Up);

		Left = new JButton("Left");
		Left.setBounds(40, 95, 80, 40);
		Left.addActionListener(this);
		panel3.add(Left);

		Down = new JButton("Down");
		Down.setBounds(80, 150, 80, 40);
		Down.addActionListener(this);
		panel3.add(Down);

		Right = new JButton("Right");
		Right.setBounds(130, 95, 80, 40);
		Right.addActionListener(this);
		panel3.add(Right);

		Move = new JButton("Move");
		Move.setBounds(300, 60, 100, 30);
		Move.addActionListener(this);
		panel3.add(Move);

		EndTurn = new JButton("EndTurn");
		EndTurn.setBounds(300, 140, 100, 30);
		EndTurn.addActionListener(this);
		panel3.add(EndTurn);

		AttackUp = new JButton("AttackUp");
		AttackUp.addActionListener(this);
		AttackUp.setBounds(560, 40, 100, 30);
		panel3.add(AttackUp);

		AttackDown = new JButton("AttackDown");
		AttackDown.setBounds(560, 150, 115, 30);
		AttackDown.addActionListener(this);
		panel3.add(AttackDown);

		AttackLeft = new JButton("AttackLeft");
		AttackLeft.setBounds(500, 95, 100, 30);
		AttackLeft.addActionListener(this);
		panel3.add(AttackLeft);

		AttackRight = new JButton("AttackRight");
		AttackRight.setBounds(640, 95, 100, 30);
		AttackRight.addActionListener(this);
		panel3.add(AttackRight);

		// panel4

		panel4 = new JPanel();
		panel4.setLayout(null);
		panel4.setBounds(10, 50, 550, 300);
		this.add(panel4);
		this.setBackground(Color.GREEN);
		this.setBackground(Color.CYAN);

		
		PickAbilityToCast = new JComboBox();
		PickAbilityToCast.setBounds(40, 50, 150, 22);
		panel4.add(PickAbilityToCast);
		
		Dimensions = new JTextArea();
		Dimensions.setBounds(340, 50,100, 100);
		Dimensions.setEditable(false);
		panel4.add(Dimensions);
		
		LeaderAbility = new JButton("Use Leader Ability");
		LeaderAbility.addActionListener(this);
		LeaderAbility.setBounds(340, 220,  180, 25);
		panel4.add(LeaderAbility);
		
		
		BoardDimensions = new JLabel("Board Dimensions");
		BoardDimensions.setBounds(340, 25, 150, 22);
		panel4.add(BoardDimensions);

		throwCast = new JButton("Throw Cast");
		throwCast.setBounds(40, 160, 100, 120);
		throwCast.addActionListener(this);
		panel4.add(throwCast);

		
		ShowBoardPosition();
		ShowCurrentMarvelInfo();
		this.validate();
		this.repaint();
	}

	// to show info of any player on board and move and attack
	public void actionPerformed(ActionEvent e) 
	{
		int length = blocks.length;

		for (int a = 0; a < length; a++) {
			for (int b = 0; b < length; b++) {

				if (e.getSource() == blocks[a][b]) {
					if (pf.getGame().getBoard()[a][b] instanceof Champion) {
						Champion champ = (Champion) pf.getGame().getBoard()[a][b];

						String DD = "Name : " + champ.getName() + "\n "
								+ "Health : " + champ.getCurrentHP() + "\n"
								+ "Action Points count: "
								+ champ.getCurrentActionPoints() + "\n"
								+ "Attack : " + champ.getAttackDamage() + "\n"
								+ "Mana :" + champ.getMana() + "\n"
								+ "Range : " + champ.getAttackRange();
								

						JOptionPane.showMessageDialog(this, DD, "info",
								JOptionPane.INFORMATION_MESSAGE);
					}
				}
			}
		}
		
		

		if (e.getSource() == Up)
			way = Direction.UP;

		if (e.getSource() == Left)
			way = Direction.LEFT;

		if (e.getSource() == Down)
			way = Direction.DOWN;

		if (e.getSource() == Right)
			way = Direction.RIGHT;

		if (e.getSource() == Move) {

			try {
				pf.getGame().move(way);

				ShowBoardPosition();
				ShowCurrentMarvelInfo();
			}

			catch (UnallowedMovementException | NotEnoughResourcesException f) {
				JOptionPane.showMessageDialog(this, f.getMessage(), "Error",
						JOptionPane.ERROR_MESSAGE);
			}

		}
		
		

		if (e.getSource() == AttackUp || e.getSource() == AttackDown
				|| e.getSource() == AttackLeft || e.getSource() == AttackRight) {

			if (e.getSource() == AttackDown)
				wayAttack = Direction.DOWN;

			if (e.getSource() == AttackLeft)
				wayAttack = Direction.LEFT;

			if (e.getSource() == AttackRight)
				wayAttack = Direction.RIGHT;

			if (e.getSource() == AttackUp)
				wayAttack = Direction.UP;

			try {
				pf.getGame().attack(wayAttack);

				ShowBoardPosition();
				this.revalidate();
				this.repaint();
				ShowCurrentMarvelInfo();

			} catch (InvalidTargetException | NotEnoughResourcesException
					| ChampionDisarmedException f) {
				JOptionPane.showMessageDialog(this, f.getMessage(), "Error",
						JOptionPane.ERROR_MESSAGE);
			}

		}
		
		
		
		if (e.getSource() == EndTurn) {
			pf.getGame().endTurn();
		}
		ShowBoardPosition();
		ShowCurrentMarvelInfo();

		this.validate();
		this.repaint();
		
		if (e.getSource() == LeaderAbility ) {
			
			try {
				pf.getGame().useLeaderAbility();
				
				
			} catch (LeaderNotCurrentException
					| LeaderAbilityAlreadyUsedException f) {
				
				f.printStackTrace();
			}
			ShowBoardPosition();
			ShowCurrentMarvelInfo();
		}

//		if (e.getSource() == throwCast)
//		{
//			
//			Ability ability = pf.getGame().getCurrentChampion().getAbilities()
//					.get(PickAbilityToCast.getSelectedIndex());
//			
//			try {
//				
//				if(ab)
//				{
//					
//				}
//				
//			else if (ability.getCastArea() == AreaOfEffect.DIRECTIONAL)
//				{
//					pf.getGame().castAbility(ability, way);
//				}
//
//				else {
//					pf.getGame().castAbility(ability);
//				}
//
//			}
//
//			catch (NotEnoughResourcesException | CloneNotSupportedException
//					| NumberFormatException | AbilityUseException f)
//			{
//				JOptionPane.showMessageDialog(this, f.getMessage(), "Invalid",
//						JOptionPane.ERROR_MESSAGE);
//			}
//
//		}// try
		

		 if(pf.getGame().checkGameOver() != null) 
		 {
			 JOptionPane.showMessageDialog(this, "The Winner is: " + pf.getGame().checkGameOver().getName() , 
					 "GameOver", 	JOptionPane.INFORMATION_MESSAGE);
		pf.dispose();	 
		 }
		 {
			 
		 }
		
	}// end method

	public void ShowCurrentMarvelInfo() {

		currentPlayerMarvel.setText(pf.showCurrentPlayerMarvelStatus());

	}

	// show players on board
	public void ShowBoardPosition() {

		for (int i = 0; i < 5; i++) {
			for (int k = 0; k < 5; k++) {

				if (pf.getGame().getBoard()[i][k] instanceof Champion) {

					if ((Champion) pf.getGame().getBoard()[i][k] == pf
							.getGame().getCurrentChampion()) {
						blocks[i][k].setBackground(Color.yellow);
					}

					else if (pf.getGame().getSecondPlayer().getTeam()
							.contains((Champion) pf.getGame().getBoard()[i][k])) {
						blocks[i][k].setBackground(Color.GREEN);

					} else {
						blocks[i][k].setBackground(Color.pink);
					}
					blocks[i][k]
							.setText(((Champion) pf.getGame().getBoard()[i][k])
									.getName()
									+ ","
									+ ((Champion) pf.getGame().getBoard()[i][k])
											.getCurrentHP() + "");
				}

				else if (pf.getGame().getBoard()[i][k] instanceof Cover) {
					blocks[i][k].setBackground(Color.BLUE);
					blocks[i][k]
							.setText(((Cover) pf.getGame().getBoard()[i][k])
									.getCurrentHP() + "");
				} else {
					blocks[i][k].setBackground(Color.WHITE);
					blocks[i][k].setText("NULL");
				}
			}
		}
	}

}
