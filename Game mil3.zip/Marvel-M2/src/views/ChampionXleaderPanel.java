package views;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class ChampionXleaderPanel extends JPanel implements ActionListener, ItemListener {

	private JButton NewGame;

	private JTextArea detailssection; // Info Area

	private JComboBox combo1; // to set champions list
	private JComboBox combo2;
	private JComboBox combo3;
	private JComboBox combo4;
	private JComboBox combo5;
	private JComboBox combo6;

	private JLabel l1;
	private JLabel l2;

	private JCheckBox check1;
	private JCheckBox check2;
	private JCheckBox check3;
	private JCheckBox check4;
	private JCheckBox check5;
	private JCheckBox check6;

	private ButtonGroup BG1;
	private ButtonGroup BG2;

	private PermanentFrame pf;

	public ChampionXleaderPanel(PermanentFrame pf) {
		
		this.setBackground(Color.CYAN);
		this.pf = pf;

		NewGame = new JButton("New Game");
		NewGame.setBounds(750, 700, 100, 30);
		this.add(NewGame);
		NewGame.addActionListener(this);

		detailssection = new JTextArea(); // Info Area
		detailssection.setBounds(360, 550, 200, 240);
		detailssection.setEditable(false);
		this.add(detailssection);

		String[] marvels = pf.importMarvels();
		
		
		combo1 = new JComboBox(marvels); // to set champions list
		combo1.setBounds(50, 100, 140, 20);
		combo1.addItemListener(this);
		this.add(combo1);

		combo2 = new JComboBox(marvels);
		combo2.setBounds(400, 100, 140, 20);
		combo2.addItemListener(this);
		this.add(combo2);

		combo3 = new JComboBox(marvels);
		combo3.setBounds(750, 100, 140, 20);
		combo3.addItemListener(this);
		this.add(combo3);

		combo4 = new JComboBox(marvels);
		combo4.setBounds(50, 400, 140, 20);
		combo4.addItemListener(this);
		this.add(combo4);

		combo5 = new JComboBox(marvels);
		combo5.setBounds(400, 400, 140, 20);
		combo5.addItemListener(this);
		this.add(combo5);

		combo6 = new JComboBox(marvels);
		combo6.setBounds(750, 400, 140, 20);
		combo6.addItemListener(this);
		this.add(combo6);

		l1 = new JLabel("First Player");
		l1.setBounds(10, 5, 100, 100);
		this.add(l1);

		l2 = new JLabel("Second Player");
		l2.setBounds(10, 300, 100, 100);
		this.add(l2);

		check1 = new JCheckBox("PickLeader");
		check1.setSelected(true);                // To Select Leader by default
		check1.setBounds(50, 120, 100, 50);
		this.add(check1);

		check2 = new JCheckBox("PickLeader");
		check2.setBounds(400, 120, 100, 50);
		this.add(check2);

		check3 = new JCheckBox("PickLeader");
		check3.setBounds(750, 120, 100, 50);
		this.add(check3);

		check4 = new JCheckBox("PickLeader");
		check4.setBounds(50, 420, 100, 50);
		this.add(check4);

		check5 = new JCheckBox("PickLeader");
		check5.setSelected(true);                // To Select Leader by default
		check5.setBounds(400, 420, 100, 50);
		this.add(check5);

		check6 = new JCheckBox("PickLeader");
		check6.setBounds(750, 420, 100, 50);
		this.add(check6);

		BG1 = new ButtonGroup();
		BG1.add(check1);
		BG1.add(check2);
		BG1.add(check3);

		BG2 = new ButtonGroup();
		BG2.add(check4);
		BG2.add(check5);
		BG2.add(check6);

		this.setLayout(null);
	}

	// Must pick 3 Marvels Error.
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == NewGame) {
			
			if (combo1.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
			else if (combo2.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
			else if (combo3.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
			else if (combo4.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
			else if (combo5.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
			else if (combo6.getSelectedIndex() == 0)
				JOptionPane.showMessageDialog(this, "Must Pick 3 Marvels", "Error", JOptionPane.ERROR_MESSAGE);
			
		
		
		
		
		
		// Marvels Must be Different error.
			else if(combo1.getSelectedIndex() == combo2.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo1.getSelectedIndex() == combo3.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo1.getSelectedIndex() == combo4.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo1.getSelectedIndex() == combo5.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo1.getSelectedIndex() == combo6.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			// Marvels Must be Different error.
			
			else if(combo2.getSelectedIndex() == combo1.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo2.getSelectedIndex() == combo3.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo2.getSelectedIndex() == combo4.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo2.getSelectedIndex() == combo5.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo2.getSelectedIndex() == combo6.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			
			// Marvels Must be Different error.
			
			else if(combo3.getSelectedIndex() == combo1.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo3.getSelectedIndex() == combo2.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo3.getSelectedIndex() == combo4.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo3.getSelectedIndex() == combo5.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo3.getSelectedIndex() == combo6.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			
			// Marvels Must be Different error.
			
			
			else if(combo4.getSelectedIndex() == combo1.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo4.getSelectedIndex() == combo2.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo4.getSelectedIndex() == combo3.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo4.getSelectedIndex() == combo5.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo4.getSelectedIndex() == combo6.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			
			// Marvels Must be Different error.
			
			else if(combo5.getSelectedIndex() == combo1.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo5.getSelectedIndex() == combo2.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo5.getSelectedIndex() == combo3.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo5.getSelectedIndex() == combo4.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo5.getSelectedIndex() == combo6.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			// Marvels Must be Different error.
			
			else if(combo6.getSelectedIndex() == combo1.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo6.getSelectedIndex() == combo2.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo6.getSelectedIndex() == combo3.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo6.getSelectedIndex() == combo4.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			else if(combo6.getSelectedIndex() == combo5.getSelectedIndex()) {
				JOptionPane.showMessageDialog(this, "Marvels Should Be Different", "Error", JOptionPane.ERROR_MESSAGE);
			}
			
			
			// to specify 1 leader for each player
			else {
			int FPL = 0;
			int SPL = 0;
			
			if (check1.isSelected()) {
				FPL = combo1.getSelectedIndex();
			}
			
			if (check2.isSelected()) {
				FPL = combo2.getSelectedIndex();
			}
			
			if (check3.isSelected()) {
				FPL = combo3.getSelectedIndex();
			}
			
			if (check4.isSelected()) {
				SPL = combo4.getSelectedIndex();
			}
			
			if (check5.isSelected()) {
				SPL = combo5.getSelectedIndex();
			}
			
			if (check6.isSelected()) {
				SPL = combo6.getSelectedIndex();
			}
			
			// call trans method
			pf.TranstoBoardPanel(combo1.getSelectedIndex() , combo2.getSelectedIndex() ,combo3.getSelectedIndex(),
					combo4.getSelectedIndex() , combo5.getSelectedIndex() , combo6.getSelectedIndex() , FPL, SPL);
			}
			
		}
		

	}

	// for viewing each champion info in details section --- infoarea
	public void itemStateChanged(ItemEvent e) {
		
		if(e.getSource() == combo1) 
			detailssection.setText(pf.importMarvelsinfo(combo1.getSelectedIndex()));
		
		else if(e.getSource() == combo2) 
			detailssection.setText(pf.importMarvelsinfo(combo2.getSelectedIndex()));

		else if(e.getSource() == combo3) 
			detailssection.setText(pf.importMarvelsinfo(combo3.getSelectedIndex()));

		else if(e.getSource() == combo4) 
			detailssection.setText(pf.importMarvelsinfo(combo4.getSelectedIndex()));
		
		else if(e.getSource() == combo5) 
			detailssection.setText(pf.importMarvelsinfo(combo5.getSelectedIndex()));
		
		else 
			detailssection.setText(pf.importMarvelsinfo(combo6.getSelectedIndex()));
			}
	

}
