package views;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import engine.Game;
import engine.Player;
import model.abilities.Ability;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Hero;
import model.world.Villain;

public class PermanentFrame extends JFrame {

	private ImageIcon image;

	private Game game;

	private String FirstPlayer;
	private String SecondPlayer;

	private Player1NamePanel player1NamePanel;
	private Player2NamePanel player2NamePanel;
	private ChampionXleaderPanel championXleaderPanel;
	private BoardPanel BP;

	public PermanentFrame() {

		player1NamePanel = new Player1NamePanel(this);
		this.getContentPane().add(player1NamePanel);

		this.setTitle("Marvel End Game");
		this.setVisible(true);
		this.setSize(500, 500);
		image = new ImageIcon("marvel_logo.jpg");
		this.setIconImage(image.getImage());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	// switch from player 1 to player 2
	public void TransPanel(String field1) {
		this.getContentPane().remove(player1NamePanel);
		this.FirstPlayer = field1;
		player2NamePanel = new Player2NamePanel(this);
		this.getContentPane().add(player2NamePanel);
		this.setSize(500, 500);

		this.validate();
		this.repaint();

	}

	// switch from player 2 to choose ( champion selection
	// panel)--ChampionXleaderPanel
	// ////////////////////////////////////////
	public void TranstoChampionXleaderPanel(String field2) {
		SecondPlayer = field2;
		this.setSize(1000, 1000);

		this.remove(player2NamePanel);

		try {
			Game.loadAbilities("Abilities.csv");
			Game.loadChampions("Champions.csv");

		}

		catch (IOException e) {
			System.out.println("Error loading file");
		}

		championXleaderPanel = new ChampionXleaderPanel(this);
		this.getContentPane().add(championXleaderPanel);

	}

	// to get list of champions in Combo box done
	// file == list
	public String[] importMarvels() {

		ArrayList<Champion> file = Game.getAvailableChampions();

		String[] f = new String[file.size()]; // +1//////////////
 /////////////////////////////////////////////////////////////////
		for (int i = 0; i < file.size(); i++) {

			String a = file.get(i).getName();
			f[i] = a;
		}
		return f;
	}

	// to get each player details.                  // turn order -- leader appears -- cast ability-- captian america
	 
	public String importMarvelsinfo(int marvelIndex) { 
		
		
		ArrayList<Champion> file = Game.getAvailableChampions();
		Champion ch = file.get(marvelIndex);

		String name = ch.getName();
		int health = ch.getCurrentHP();
		int attackDamage = ch.getAttackDamage();
		int attackRange = ch.getAttackRange();
		int M = ch.getMana();
		

		String k = "Name : " + name + "\n" 
		+ "Health : " + health + "\n"

		+ "Attack : " + attackDamage + "\n"

		+ "Range : " + attackRange + "\n"

		+ "Mana : " + M + "\n" 
		
		+ "Abilities : " + "\n";

		for (int i = 0; i < ch.getAbilities().size(); i++) {

			k = k + " - " + ch.getAbilities().get(i).getName() + "\n"; 
																			
		}

		return k;
	}

	// To Trans from ChampionXleader to BoardPanel
	public void TranstoBoardPanel(int a, int b, int c, int x, int y, int z,
			int FPL, int SPL) {
		this.remove(championXleaderPanel);

		Player gamer2 = new Player(SecondPlayer);
		gamer2.getTeam().add(Game.getAvailableChampions().get(x));
		gamer2.getTeam().add(Game.getAvailableChampions().get(y));
		gamer2.getTeam().add(Game.getAvailableChampions().get(z));
		gamer2.setLeader(Game.getAvailableChampions().get(SPL));

		Player gamer1 = new Player(FirstPlayer);
		gamer1.getTeam().add(Game.getAvailableChampions().get(a));
		gamer1.getTeam().add(Game.getAvailableChampions().get(b));
		gamer1.getTeam().add(Game.getAvailableChampions().get(c));
		gamer1.setLeader(Game.getAvailableChampions().get(FPL));

		game = new Game(gamer1, gamer2);

		BP = new BoardPanel(this,game); //////////////////////////////////////////
		this.getContentPane().add(BP);
		this.setSize(1400, 1200);

		this.repaint();
		this.validate();

	}

	public String showCurrentPlayerMarvelStatus() {
		String DD = " * Current Player : ";
		String FPName = game.getFirstPlayer().getName();
		String SPName = game.getSecondPlayer().getName();
		Champion champ = game.getCurrentChampion();

		if (game.getSecondPlayer().getTeam()
				.contains(game.getCurrentChampion())) {
			DD = DD + SPName + "\n";
		}

		else {
			DD = DD + FPName + "\n";
		}

		DD = DD +  "* Current Marvel Status: " + "\n"  + "Name : "
				+ champ.getName() + "\n " + "* Health : " + champ.getCurrentHP()
				+ "\n" + "* Action Points count: "
				+ champ.getCurrentActionPoints() + "\n" + "* Attack : "
				+ champ.getAttackDamage() + "\n" + "* Mana :" + champ.getMana()
				+ "\n"  + "* Range : " + champ.getAttackRange() + "\n"+  "\n"
				+ "* Abilities : " + "\n";

		int i = 0; 
		while (i < champ.getAbilities().size()) {
			DD = DD + (i + 1) + ")" + champ.getAbilities().get(i).getName()+ ":";

			DD = DD  + "\n"+ "#Area of Effect:"
					+ champ.getAbilities().get(i).getCastArea() + "\n";
			DD = DD + "# Cool Down:"
					+ champ.getAbilities().get(i).getCurrentCooldown() + "\n";
			DD = DD + "# Action Points:"
					+ champ.getAbilities().get(i).getRequiredActionPoints()
					+ "\n\n";
			
			if(champ instanceof Villain)
			{
				DD=DD + "Villain";
			}
			if(champ instanceof Hero)
			{
				DD=DD + "Hero";
			}
			if(champ instanceof AntiHero)
			{
				DD=DD + "AntiHero";
			}
			
			DD = DD + " # Mana Cost:"
					+ champ.getAbilities().get(i).getManaCost() + "\n" + "Applied Effects: " +"\n"  ;
				
			i++;
		}
		int	j= 0; 
		while(j< game.getCurrentChampion().getAppliedEffects().size())
	
		{
			DD = DD +  (j + 1) + ")" +game.getCurrentChampion().getAppliedEffects().get(j).getName() + ":";
	
			j++;
		}
		return DD;
	}

	public Game getGame() {
		return game;
	}

	public static void main(String[] args) {

		PermanentFrame F = new PermanentFrame();
	}

}
