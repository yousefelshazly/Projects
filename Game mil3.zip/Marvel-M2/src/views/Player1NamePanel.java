package views;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Player1NamePanel extends JPanel implements ActionListener {

	private JButton Next;
	private JLabel label;
	
	private JTextField field1;
	private PermanentFrame pf;

	public Player1NamePanel(PermanentFrame pf) {
		this.setBackground(Color.PINK);
		this.pf = pf;

		label = new JLabel("First Player Name");
		label.setBounds(200,100,100,100);
		this.add(label);

		field1 = new JTextField("Ahmad");
		field1.setBounds(190, 180, 125, 25);
		this.add(field1);
		field1.addActionListener(this);

		Next = new JButton("Next");
		Next.setBounds(190, 220, 120, 25);
		this.add(Next);
		Next.addActionListener(this);

		this.setLayout(null);
	}
	

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == Next) {

			if (field1.getText().equals("")) {

				JOptionPane.showMessageDialog(this, "Please Enter First Player Name", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else
				pf.TransPanel(field1.getText());
		}

	}

}
