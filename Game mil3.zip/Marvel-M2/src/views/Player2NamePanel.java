package views;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class Player2NamePanel extends JPanel implements ActionListener {
	
	private JButton Next;
	
	private JLabel label;
	
	private JTextField field2;
	
	private PermanentFrame pf;

	
	public Player2NamePanel (PermanentFrame pf){
		
	this.pf=pf;
	this.setBackground(Color.PINK);
	
	
	label = new JLabel ("Second Player Name");
	label.setBounds(195,100,200,100);
	this.add(label);
	
	field2 = new JTextField("Omar");
	field2.setBounds(190,180,125,25);
	this.add(field2);
	field2.addActionListener(this);
	
	Next = new JButton("Next");
	Next.setBounds(190,220, 120, 25);
	this.add(Next);
	Next.addActionListener(this);
	
	
	this.setLayout(null);
	}
	
	
	
	
	public void actionPerformed(ActionEvent e) {

		if(e.getSource()== Next) {
			
			if(field2.getText().equals("")) {
				
				JOptionPane.showMessageDialog(this, "Please Enter Second Player Name", "Error", JOptionPane.ERROR_MESSAGE);
				}
			else
				pf.TranstoChampionXleaderPanel(field2.getText());
		}
		
		
	}
	

	
}